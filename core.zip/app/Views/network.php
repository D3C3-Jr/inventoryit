<?= $this->extend('templates/layout'); ?>

<?= $this->section('content'); ?>
<h2><?= $title; ?></h2>
<?= $this->endSection(); ?>